
# Contact Management System

A simple Python program to manage your contacts with features like:
- Add new contact (name, phone, email)
- View all contacts
- Edit a contact
- Delete a contact

## Usage

1. Run the script:
```bash
python contact_manager.py
```

2. Follow the menu to perform operations.

## Data Storage

- Contacts are saved in a `contacts.json` file to retain data between runs.

## Requirements

- Python 3.x

